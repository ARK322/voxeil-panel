This directory is the Docker build context for images used by Kubernetes services.

Kubernetes manifests live under `infra/k8s/services`.
